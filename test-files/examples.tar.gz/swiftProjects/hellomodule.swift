// a swift project file
// include: today.swift

import Foundation

print("Hello World")

printToday() // func from today.swift 
