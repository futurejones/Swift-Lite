// a swift project file

import Foundation
import Today

print("Hello World")
printToday() // func from libToday library
